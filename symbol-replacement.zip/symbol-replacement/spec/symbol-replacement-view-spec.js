'use babel';

import SymbolReplacementView from '../lib/symbol-replacement-view';

describe('SymbolReplacementView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
