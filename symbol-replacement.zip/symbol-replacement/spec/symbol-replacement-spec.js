'use babel';

import 'fs';
import 'path';
import 'temp';

import SymbolReplacement from '../lib/symbol-replacement';

// Use the command `window:run-package-specs` (cmd-alt-ctrl-p) to run specs.
//
// To run a specific `it` or `describe` block add an `f` to the front (e.g. `fit`
// or `fdescribe`). Remove the `f` to unfocus the block.

describe('SymbolReplacement', () => {
  // Set up editor with example file for tests.
  beforeEach(() => {
    const directory = temp.mkdirSync();  // Temp directory to work on example file.
    atom.project.setPaths([directory]);
    workspaceElement = atom.views.getView(atom.workspace);  // HTMLElement view.

    filePath = path.join(directory, 'example.c');  // Temp file to work on.
    fs.writeFileSync(filePath, 'lambda\nlambd\n');

    waitsForPromise(() => {
      return atom.workspace.open(filePath);
    });
  });

  afterEach(() => {
    temp.cleanupSync();  // Clean the temp directory.
  });

  describe('when an editor is added to the symbol-replacement package', () => {
    it('replaces all the symbols in the editor', () => {
      const sre = symbolReplaceEditor(atom.workspace.getActiveTextEditor(), {
        'lambda': '\\'
      });

      // 
    });
  });

  describe('when a file type is added to the symbol-replacement package', () => {
    it('replaces all symbols for that file type', () => {
      const srft = symbolReplaceFileType('.c', {
        'lambda': '\\'
      });
    });
  });
});
